
if require("Internet").run("https://raw.githubusercontent.com/IgorTimofeev/MineOS/master/Installer/Main.lua") == nil then
	computer.shutdown(true)
end
